/*
  Replaces original hw.h used in default build.
*/
#include "Globals.h"
#include "SPI.h"
#include "UART.h"
